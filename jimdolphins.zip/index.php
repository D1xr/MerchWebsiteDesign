 <title>&AElig; jimdolphins</title>  

  <link href="image/jimdolphinbg-modified-r.png" rel="shortcut icon" type="favicon"/>
  <link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/normalize/4.2.0/normalize.min.css'>
<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/typicons/2.0.8/typicons.min.css'>
 <link rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
     <link rel="stylesheet" href="css/style.css">

  <link rel='stylesheet prefetch' href='https://cdn.rawgit.com/michalsnik/aos/2.0.4/dist/aos.css'>
 <link rel="stylesheet" href="css/swiper.min.css">

<style>

.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999999999;
  background: url(image/loadingicon.gif) center no-repeat #fff;
}
</style>
<script data-token="GRjFrYdzwwlMAr8nEksOutFE9NVTKRmOEccgcl5SuyjqJCVJhtmbzqGnoma9uiY8" src="https://etsy360.io/widgets/js/etsy360.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
<script>

  $(window).load(function() {
  
    $(".se-pre-con").fadeOut("slow");;
  });
</script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-166446302-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-166446302-1');
</script>


  <body  >
     <div class="wrapper" style = "padding-bottom: 0px;">
		<span>🐬</span>
		<span>🐬</span>
		<span>🐬</span>
		<span>🐡</span>
		<span>🐡</span>
		<span>🐡</span>
		<span>🍣</span>
		<span>🍣</span>
		<span>🐟</span>
		<span>🐬</span>
</div>
 <!--
  <div id="particles-js"></div>
  

<script src="js/particles.js"></script>
  -->

<div class="se-pre-con"></div>

      <style>
@media only screen and (max-device-width: 768px) {
.swiper-container-horizontal>.swiper-pagination-bullets, .swiper-pagination-custom, .swiper-pagination-fraction{
    top: 1200px;
  }
}
@media only screen and  (max-device-width: 768px) and (orientation:landscape){
   top: 1000px;
}
.swiper-container-horizontal>.swiper-pagination-bullets, .swiper-pagination-custom, .swiper-pagination-fraction{
  bottom: 110px;
}

.swiper-button-prev{
  color:black;
}

:root {
    --swiper-theme-color: #000000;
}
.swiper-button-next{
color: black;
}
  </style>

  <section id="ope">
  <p>   &nbsp;  &nbsp;</p>

  <center>
   <h1 style="color: white;">Please resize your window for best experience</h1>
 </center>
 </section>

<section id = "opening">
<div  data-aos="zoom-in" >
<center>
<img id="myImage" src="image/jimdalogo.png"  class="zoom2">

</center>
</div>
<center>
                               
<titlee>  
	<span id="L">I</span>
	<span id="I">---</span>
	<span id="G">L</span>
	<span id="H">O</span>
	<span id="P">V</span>
  <span id="I">3</span>
	<span id="C">-</span>
	<span id="K">j</span>
	<span id="L">i</span>
	<span id="E">m</span>

  </titlee>

</center>
<center><h1><titlee>A <smt style = "color: green">Rest</smt>aurant<sup ><a href="https://github.com/D1xr" target = "_blank" style="font-size:10px"><b>[i]</b></a></sup><br>
  <span class="ityped"></span>
        <script src="https://unpkg.com/ityped@0.0.10"></script>
      <script>
            window.ityped.init(document.querySelector('.ityped'),{
                strings: ['Get Fit and Get a Fridge💪🍽️','Embrace the average/achievable physique 🐬!','no abs no problem', 'Time to pick up a fork and show gravity whos boss'],
                loop: true
            })
        </script>
    </titlee></h1>

<button id ="ChangeColorWhite" class="button1" >White</button>
<button id ="ChangeColorBlack" class="button2" >Black</button>
</center>
<p>   &nbsp;  &nbsp;</p>

<center>
<div id ="smooth" >
<a id ="smooth" href="#buy" class="downArrow bounce">
  <img id = "daArrow" width="40" height="40" alt="" src="image/whiteArrow.png" />
</a>
</div>
</center>
<button  onClick="gotop(500)" id="topp" title="top" style="display: block;">Top </button>

<!--
<button  onClick="offanimation()" id="topp2" title="top" style="display: block;">Toggle animation </button>
-->
<p>&nbsp;&nbsp;&nbsp;&nbsp;</p>
</section>
<style> .carousel-inner img {
    width: 40%;
    height: 40%;
  }</style>
<section id="buy">
    <p>   &nbsp;  &nbsp;</p>
    <center>
    <h1  data-aos="fade-up"><subtitlee>Products</subtitlee></h1>
   </center>

<div class="swiper-container"  data-aos="zoom-in">
    <div class="swiper-wrapper">
 <div  class="swiper-slide" >
     <div class="member"> 
    <div class="container" >
       <center><p id ="prodname"><subtitlee>Merch</subtitlee></p></center>

<div id="featured-listings"> </div>

</div>
     </div>
     

     
</div>
<div  class="swiper-slide"> 
<div class="member">   
<div class="container" >



          <center><p id ="prodname"><subtitlee>Instagram posts</subtitlee></p></center>
    &nbsp;<br/>
   <figure data-behold-id="d7sd3A0hDbzPWeJ7Z8Fv"></figure>
<script src="https://w.behold.so/widget.js" type="module"></script>
   </div>
   
   </div>
   
   </div>
</div>

    <div class="swiper-button-next bounce2"></div>
    <div class="swiper-button-prev bounce3"></div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
</div>




</section>

<section id="faq">

     <p>   &nbsp;  &nbsp;</p>
    <center>
    <h1 data-aos="fade-up"><titlee><b>F.A.Q</b></titlee></h1>
    </center>
      <center><p><blog class="blog"><a href="https://frychicken.github.io/blog/" target = "_blank"><titlee>Blog post & announcement</titlee></a></blog></p></center>
    <center><titlee><p> &nbsp;<br/>Limited number of this will be released for free, email me if you want one.</p></titlee></center>

<hr id = "linee" data-aos="zoom-in">
  <center><subtitlee><p>&nbsp;</p></subtitlee> </center>


<button class="collapsible" data-aos="fade-right">Shirt modifications?</button>
<div class="content">
<center>

<titlee>
<p><i>
    &nbsp;<br/>
It is best to crop the shirt or to buy a bigger shirt
</i></p>

<p>
At present, the product offering is the T-Shirt. For a customized fit, customers have the option to modify it into a tank top by cropping. Additionally, those desiring an oversized style may opt for a larger size.
</p>
</titlee>
</center>

<hr id = "lineee">
</div>
<center><subtitlee><p>&nbsp;</p></subtitlee> </center>


<button class="collapsible" data-aos="fade-right">Any affiliation with Gymshark?</button>
<div class="content">
<center>

<titlee>
<p><i>
    &nbsp;<br/>
Nuh uh
</i></p>

<p>
This is a restaurant and not a clothing company. The restaurant promotes body positivity regardless of how muscular you are, no abs no problem!

</p>
</titlee>
</center>

<hr id = "lineee">
</div>

<center><subtitlee><p>&nbsp;</p></subtitlee> </center>
<button class="collapsible" data-aos="fade-right">Free Shipping?</button>
<div class="content">
<center>

<titlee>
<p><i>
    &nbsp;<br/>
Maybe.
</i></p>

<p>
Working on it. 

</p>
</titlee>

</center>
<hr id = "lineeee">
</div>


</section>

<section id="contact" >
    <p>   &nbsp;  &nbsp;</p>
    <center>
    <h1 data-aos="fade-up"><subtitlee >Contact</subtitlee></h1>
    
    </center>
    <p>&nbsp;&nbsp;&nbsp;&nbsp;</p>
    <div class = "member">
<div  data-aos="zoom-in" >
<center>
    <a href="https://github.com/frychicken" target = "_blank">
<img src="image/mer.png"  width="110" height="110" class="zoom">
</a>
</center>
<center><p><b><subtitlee>J</subtitlee></b></p>
<center><p><subtitlee>CEO/Front-end Engineer</subtitlee></p></center>
<center><p><subtitlee>email: bob@null0verflow.xyz</subtitlee></p></center>
</center></div>

<div  data-aos="zoom-in" >
  <center>
<p>&nbsp;&nbsp;&nbsp;&nbsp;</p>
</center>
</div>

<div  data-aos="zoom-in" >
 <center> 
    <a href="https://www.instagram.com/jimdolphins" target = "_blank">
<img src="image/jimdolphinbg-modified-r.png"  width="110" height="110" class="zoom">
</a>
<p><b><subtitlee>@jimdolphins</subtitlee></b></p>
<center><p><subtitlee>Instagram page</subtitlee></p></center>
<center><p><subtitlee>@jimdolphins on insta</subtitlee></p></center>
</center>
</div>
</div>
    <p>   &nbsp;  &nbsp;</p>
        <p>   &nbsp;  &nbsp;</p>

<hr data-aos="zoom-in">
  <p>   &nbsp;  &nbsp;</p>
    <p>   &nbsp;  &nbsp;</p>

<center><subtitlee></subtitlee></center>
</section>
  <div id="cr">
      <p>   &nbsp;  &nbsp;</p>
<center><p><titlee>Copyright &copy; 2023 null0verflow AshE. All rights reserved.</titlee></p></center>
  <p>   &nbsp;  &nbsp;</p>
  </div>



<?php
          $filefdata = fopen("announcement/ann.txt", "r") or die("Unable to open file!");
while(! feof($filefdata))
  {
   
      ?>
      
      <div id="aaaa" class="announcement">
              &nbsp;<br/>
  <p  >    &nbsp;<br/>Announcement: <?php echo fgets($filefdata)." ";?>!&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="https://frychicken.github.io/blog/" target = "_blank">Full Story ></a> <a  style="cursor:pointer"  onclick="toggle_visibility();">&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;close</a>    &nbsp;<br/></p>    &nbsp;<br/>
</div>
          
        <?php
  }

fclose($filefdata);

?>



<div id="navbar" class="navi" style="top: 0px;">
<center>
    
      <img id ="navRight" src="image/optimizedImage/Hi.svg" width="40" height="40">
 <div  id="sticky">Home</div>
<a href="https://frychicken.github.io/blog/" target = "_blank">Blog</a>
 <a id ="cc" href="#contact">Contact</a>
  <a id="ff" href="#faq">F.A.Q</a>
      <a id="bbb" href ="#buy">Products</a>

</center>
</div>


<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/gsap/1.19.0/TweenMax.min.js'></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
  <script src="https://cldup.com/S6Ptkwu_qA.js"></script>


<script src ='js/javascript.js'></script>
  <script src="js/swiper.min.js"></script>

<script src='https://cdn.rawgit.com/michalsnik/aos/2.0.4/dist/aos.js'></script>
    <script>AOS.init({
  duration: 1200,
})

  var swiper = new Swiper('.swiper-container', {
      cssMode: true,
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      pagination: {
        el: '.swiper-pagination'
      },
      mousewheel: true,
      keyboard: true,
    });
</script>



</body>