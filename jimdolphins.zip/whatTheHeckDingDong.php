<?php
error_reporting(0);
error_reporting(E_ALL & ~E_NOTICE);
$apass = "17baf219db9124d4fa1a16874827abdc7d9f4865e08ab70e470c1a8acdf42190";

$pass = hash('sha256', $_POST["pass"]);
$nameadd = $_POST["usernameadd"];

 if ( $pass==$apass ){
     
$myfile = fopen("announcement/ann.txt", "w") or die("Unable to open file!");
$txt = $nameadd;
fwrite($myfile, $txt);
     
     echo "added!";

    }
        else{
echo "wrong password";
}



?>
<center>
<info><h3></h3></info>

<form action="" method="post"><br>
Announcement:<br> <input type="text" name="usernameadd" placeholder="announcement"><br>
<br>
Password:<br> <input type="password" name="pass" placeholder="password" ><br>

<input type="submit" value="Add!">
